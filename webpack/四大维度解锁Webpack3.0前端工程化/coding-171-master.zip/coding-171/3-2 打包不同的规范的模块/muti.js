// AMD

define(function(require, factory) {
    'use strict';
    return function(a, b) {
        return a * b
    }
});