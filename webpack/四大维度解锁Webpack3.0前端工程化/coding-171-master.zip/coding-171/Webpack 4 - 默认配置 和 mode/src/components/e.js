import 'preact'
import { compact } from 'lodash-es'

compact([0, 1, false, 5, '', 3]);

export default 'I am e'