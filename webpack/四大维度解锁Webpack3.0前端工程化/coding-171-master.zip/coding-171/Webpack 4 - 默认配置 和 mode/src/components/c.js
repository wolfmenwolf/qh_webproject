import 'preact'
import { compact } from 'lodash-es'

export default 'I am c'