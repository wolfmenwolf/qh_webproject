import('./components/a')
import('./components/b')
import('./components/c')
import('./components/f')

console.log('hello app')
export default 'i am app'