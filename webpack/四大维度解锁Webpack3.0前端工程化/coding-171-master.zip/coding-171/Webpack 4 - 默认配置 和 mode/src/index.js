import('./components/a')
import('./components/b')
import('./components/c')
import('./components/d')
import('./components/e')
import('./components/f')

console.log('hello index')
export default 'i am index'