export default {
  todos: state => state.todos
}
