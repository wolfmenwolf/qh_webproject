<template>
  <div>
    <router-link to="/"> home </router-link>
    <router-link to="todos"> todos </router-link>
    <h1>this is home</h1>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>

</style>
