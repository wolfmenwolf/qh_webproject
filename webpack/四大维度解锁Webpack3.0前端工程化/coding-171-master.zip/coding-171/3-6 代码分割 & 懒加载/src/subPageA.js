import './moduleA'

console.log('this is subpageA')
export default 'subPageA'