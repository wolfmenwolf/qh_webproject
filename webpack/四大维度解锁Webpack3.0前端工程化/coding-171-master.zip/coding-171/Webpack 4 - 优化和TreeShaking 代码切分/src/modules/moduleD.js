import { minus } from './moduleA'
minus(4, 2)

export default 'this is D'