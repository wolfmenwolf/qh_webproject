export const add = function (a, b) {
    return a + b
}

export const minus = function (a, b) {
    return a - b
}

export const self = 'this is A'