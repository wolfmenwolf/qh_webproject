export function a () { console.log(1) }
export function b () { console.log(2) }
export function c () { console.log(3) }