import('./subPageA')
import('./subPageB')

import * as _ from 'lodash'

export default 'pageA'