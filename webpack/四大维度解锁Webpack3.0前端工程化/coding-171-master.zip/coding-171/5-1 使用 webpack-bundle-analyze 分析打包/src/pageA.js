// import * as _ from 'lodash'
var page = 'subpageA'
import subPageA from './subPageA'
import subPageB from './subPageB'

console.log(subPageA)
console.log(subPageB)


export default 'pageA'