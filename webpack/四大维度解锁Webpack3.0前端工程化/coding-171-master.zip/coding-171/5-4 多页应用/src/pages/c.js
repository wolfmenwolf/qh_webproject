import react from 'react'
import moduleA from '../components/module'
import '../css/c.css'

console.log('i am c')
console.log(moduleA)