import react from 'react'
import moduleA from '../components/module'
import '../css/b.css'

console.log('i am b')
console.log(moduleA)