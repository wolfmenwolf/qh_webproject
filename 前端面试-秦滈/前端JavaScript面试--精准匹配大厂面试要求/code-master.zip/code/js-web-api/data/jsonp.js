abc(
    { name: 'xxx' }
)