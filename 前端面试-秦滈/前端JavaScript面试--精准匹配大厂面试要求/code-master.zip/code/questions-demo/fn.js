// // 函数声明
// const res = sum(10, 20)
// console.log(res)
// function sum(x, y) {
//     return x + y
// }

// // 函数表达式
// var res = sum(10, 20)
// console.log(res)
// var sum = function (x, y) {
//     return x + y
// }
