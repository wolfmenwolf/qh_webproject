// var carName = 'Volvo'
// function myFunction () {
//   bar = 2
//   console.log(carName)
// }
//
// myFunction()
// console.log(carName)
// console.log(bar, window.bar)
// delete window.bar
// console.log(window.bar)
// delete carName
// console.log(carName);
// eval('var name=2')

// function bar (value) {
//   var testValue = 'inner'
//   var result = testValue + value
//   function innser () {
//     return result
//   }
//   return innser()
// }
//
// console.log(bar('fun'))
// {
//   let a = 1
//   console.log(a)
// }
// console.log(a)
