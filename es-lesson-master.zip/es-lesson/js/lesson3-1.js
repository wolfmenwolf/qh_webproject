// const arr = [1, 2, 3, 4, 5, 6, 7]
//
// console.log(arr.includes(40))

console.log(2 ** 6)
