export default [
  {
    id: "1",
    name: "Kennedy",
    job: "Chief Mobility Orchestrator",
    city: "North Alec",
  },
  {
    id: "2",
    name: "Lucius",
    job: "Internal Research Manager",
    city: "Littleland",
  },
  {
    id: "3",
    name: "Carlos",
    job: "Lead Configuration Analyst",
    city: "South Lillian",
  },
  {
    id: "4",
    name: "Urban",
    job: "Chief Operations Agent",
    city: "Shieldshaven",
  },
  {
    id: "5",
    name: "Katrine",
    job: "Legacy Solutions Orchestrator",
    city: "South Kyleigh",
  },
  {
    id: "6",
    name: "Kennedi",
    job: "Global Assurance Developer",
    city: "East Jaunitaville",
  },
  {
    id: "7",
    name: "Mariah",
    job: "Forward Functionality Administrator",
    city: "West Kody",
  },
  {
    id: "8",
    name: "Danika",
    job: "Forward Applications Developer",
    city: "Lake Max",
  },
  {
    id: "9",
    name: "Freeda",
    job: "Legacy Tactics Officer",
    city: "North Brandonview",
  },
  {
    id: "10",
    name: "Lila",
    job: "Future Research Coordinator",
    city: "South Helenabury",
  },
];
