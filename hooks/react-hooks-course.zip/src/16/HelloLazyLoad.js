export default () => "Hello Lazy Load!";
