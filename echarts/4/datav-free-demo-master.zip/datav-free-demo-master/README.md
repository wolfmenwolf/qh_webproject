# 慕课网《快速入门ECharts4.0开发》源码

## 快速开始

### 安装依赖
```
npm install
```

### 启动项目
```
npm run serve
```

### 构建项目
```
npm run build
```
